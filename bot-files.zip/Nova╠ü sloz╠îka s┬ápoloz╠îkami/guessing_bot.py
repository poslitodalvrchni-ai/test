import discord
from discord.ext import commands, tasks
import datetime

# --- CONFIGURATION ---
# Enter your Bot Token here (keep this secret!)
TOKEN = "YOUR_BOT_TOKEN_HERE"

# --- SETUP ---
# We need intents to read message content and manage reactions
intents = discord.Intents.default()
intents.message_content = True
intents.reactions = True

bot = commands.Bot(command_prefix='!', intents=intents)

# --- GAME STATE CLASS ---
class GameState:
    def __init__(self):
        self.is_active = False
        self.target_channel_id = None
        self.answer = ""
        self.hints = []
        self.hints_revealed = 0
        self.last_hint_time = None

# Initialize global game state
game = GameState()

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name}')
    print('Bot is ready to host games!')

# --- ADMIN COMMANDS ---

@bot.command()
async def set_answer(ctx, *, secret_word: str):
    """Sets the secret answer for the game."""
    if game.is_active:
        await ctx.send("⚠️ A game is already running! Stop it first with !stop_game")
        return
    
    game.answer = secret_word.strip().lower()
    await ctx.message.delete() # Delete the admin's message so no one sees the answer
    await ctx.send(f"🔐 The secret answer has been set (Hidden).")

@bot.command()
async def add_hint(ctx, *, hint_text: str):
    """Adds a hint to the queue (up to 5). Usage: !add_hint The object is red."""
    if len(game.hints) >= 5:
        await ctx.send("⚠️ You can only store up to 5 hints.")
        return
    
    game.hints.append(hint_text)
    await ctx.send(f"📝 Hint #{len(game.hints)} added.")

@bot.command()
async def clear_hints(ctx):
    """Clears all saved hints."""
    game.hints = []
    await ctx.send("🗑️ All hints cleared.")

@bot.command()
async def start_game(ctx):
    """Starts the guessing game in the current channel."""
    if not game.answer:
        await ctx.send("❌ You haven't set an answer yet! Use !set_answer <word>")
        return
    if not game.hints:
        await ctx.send("❌ You haven't added any hints! Use !add_hint <text>")
        return
    if game.is_active:
        await ctx.send("⚠️ Game is already running.")
        return

    # Initialize Game
    game.is_active = True
    game.target_channel_id = ctx.channel.id
    game.hints_revealed = 0
    game.last_hint_time = datetime.datetime.now()
    
    await ctx.send(f"🎮 **Game Started!** I will drop hints periodically. guess the answer!")
    
    # Start the background checking loop
    game_loop.start()

@bot.command()
async def stop_game(ctx):
    """Forces the game to stop."""
    game.is_active = False
    game_loop.cancel()
    await ctx.send("🛑 Game stopped manually.")

# --- BACKGROUND LOOP ---

@tasks.loop(hours=1.0)
async def game_loop():
    """
    This task runs every 1 hour.
    1. It checks message history for the correct answer.
    2. It posts a new hint if enough time has passed.
    """
    if not game.is_active or not game.target_channel_id:
        return

    channel = bot.get_channel(game.target_channel_id)
    if not channel:
        return

    print("Checking messages for the winner...")

    # 1. CHECK FOR WINNERS
    # We scan the last 500 messages to ensure we catch any answers from the last hour
    messages_to_check = [message async for message in channel.history(limit=500)]
    
    winner_found = False
    
    for message in messages_to_check:
        # Don't check the bot's own messages
        if message.author == bot.user:
            continue

        # Check if the message content matches the answer
        if message.content.lower().strip() == game.answer:
            await message.add_reaction("✅")
            await message.add_reaction("🎉")
            await channel.send(f"🏆 **We have a winner!** {message.author.mention} guessed correctly: **{game.answer}**")
            winner_found = True
            break
    
    if winner_found:
        game.is_active = False
        game.hints = [] # Reset hints for next time
        game_loop.stop()
        return

    # 2. POST HINTS
    # Logic: Post a hint every 2 minutes (every 2nd loop iteration)
    # You can adjust this logic if you want them faster or slower
    time_since_last_hint = datetime.datetime.now() - game.last_hint_time
    
    # If 2 minutes have passed and we still have hints to reveal
    if time_since_last_hint.total_seconds() > 120 and game.hints_revealed < len(game.hints):
        
        next_hint = game.hints[game.hints_revealed]
        hint_number = game.hints_revealed + 1
        
        embed = discord.Embed(title=f"🕵️ Hint #{hint_number}", description=next_hint, color=0x00ff00)
        await channel.send(embed=embed)
        
        game.hints_revealed += 1
        game.last_hint_time = datetime.datetime.now()

    # If all hints shown and lots of time passed, maybe end game? (Optional)
    elif game.hints_revealed >= len(game.hints) and time_since_last_hint.total_seconds() > 300:
        await channel.send(f"⌛ No one guessed it! The answer was: ||{game.answer}||")
        game.is_active = False
        game.hints = []
        game_loop.stop()

# Start the bot
if __name__ == "__main__":
    try:
        bot.run(TOKEN)
    except Exception as e:
        print(f"Error starting bot: {e}")
        print("Did you remember to put your Token in the TOKEN variable?")